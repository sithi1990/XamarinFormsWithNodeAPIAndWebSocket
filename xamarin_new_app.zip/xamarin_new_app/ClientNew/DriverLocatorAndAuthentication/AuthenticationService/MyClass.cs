﻿using System;

namespace AuthenticationService
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

