﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using ModernHttpClient;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Common
{
    public class HttpRequestHandler
    {
        public string AccessToken { get; set; }
        public string Url { get; set; }
        public string Method { get; set; }
        public TResult SendRequest<T,TResult>(T t)
        {
            HttpClient httpClinet = new HttpClient(new NativeMessageHandler());
            var request = new HttpRequestMessage();
            request.Method = Method == "POST" ? HttpMethod.Post : HttpMethod.Get;
            //HttpWebRequest request = WebRequest.Create(Url) as HttpWebRequest;
            httpClinet.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            request.RequestUri = new Uri(Url);
            if (!String.IsNullOrEmpty(AccessToken))
            {
                request.Headers.Add("x-access-token", AccessToken);
            }

            if (t != null)
            {
                request.Content = new StringContent(JsonConvert.SerializeObject(t, Formatting.Indented), Encoding.UTF8, "application/json");
            }
            try
            {
                var result = httpClinet.SendAsync(request).Result;
                string resultJson = result.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<TResult>(resultJson);
            }
            catch(Exception ex)
            {
                throw ex;
            }
          
                       
        }

        public TResult SendRequest<TResult>()
        {
            return SendRequest<object,TResult>(null);
        }
    }
}
