﻿using System;

namespace DriverLocatorService
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

