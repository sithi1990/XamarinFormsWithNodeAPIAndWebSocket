﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Authentication.Common;
using Common;
using DriverLocator.Models;

namespace DriverLocator
{
    public class DriverLocatorService
    {

        private const string GET_USERS_URL = "http://172.28.40.120:8079/api/usercoordinates";
        private const string SAVE_USERS_URL = "http://172.28.40.120:8079/api/saveuserdata";
        private const string UPDATE_USER_COORDINATE_URL = "http://172.28.40.120:8079/api/updatecoordinates";
		private const string SELECTED_USER_COORDINATE_URL = "http://172.28.40.120:8079/api/selectedusercoordinate";
        private const string WEB_SOCKET_URL = "http://172.28.40.120:8079/";

        IAuthenticationService authenticationService;
        //private Socket socketConnection;

        //public event EventHandler<string> OnMapUpdatedNotificationReceived;

        public DriverLocatorService(IAuthenticationService authenticationService)
        {
            this.authenticationService = authenticationService;
            InitNotificationService();
        }

        public DriverLocatorService()
        {
            InitNotificationService();
        }

        private void InitNotificationService()
        {
            //socketConnection = IO.Socket(WEB_SOCKET_URL);
            //socketConnection.On("coordinate_changed", On_CoordinateChanged);
        }

        private void On_CoordinateChanged(object data)
        {
            //OnMapUpdatedNotificationReceived(this, data.ToString());
        }

        public UserCoordinatesResponse ViewUserCoordinates()
        {
            HttpRequestHandler requestHandler = new HttpRequestHandler();
            requestHandler.AccessToken = authenticationService.AuthenticationToken;
            requestHandler.Method = "GET";
            requestHandler.Url = GET_USERS_URL;
            var userCoordinateResponse=requestHandler.SendRequest<UserCoordinatesResponse>();
            return userCoordinateResponse;
        }


//        public UserCoordinatesResponse SaveUser()
//        {
//            HttpRequestHandler requestHandler = new HttpRequestHandler();
//            requestHandler.AccessToken = authenticationService.AuthenticationToken;
//            requestHandler.Method = "POST";
//            requestHandler.Url = SAVE_USERS_URL;
//            var userCoordinateResponse = requestHandler.SendRequest<UserCoordinatesResponse>();
//            return userCoordinateResponse;
//        }

        public SaveUserDataResponse SaveUserData(UserCoordinate userCoordinate)
        {
            HttpRequestHandler requestHandler = new HttpRequestHandler();
            requestHandler.AccessToken = authenticationService.AuthenticationToken;
            requestHandler.Method = "POST";
            requestHandler.Url = UPDATE_USER_COORDINATE_URL;
            var result=requestHandler.SendRequest<UserCoordinate, SaveUserDataResponse>(userCoordinate);
            return result;
        }


		public SelectedUserCoordinateResponse GetSelectedUserCoordinate()
		{
			HttpRequestHandler requestHandler = new HttpRequestHandler();
			requestHandler.AccessToken = authenticationService.AuthenticationToken;
			requestHandler.Method = "GET";
			requestHandler.Url = UPDATE_USER_COORDINATE_URL;
			var result=requestHandler.SendRequest<SelectedUserCoordinateResponse>();
			return result;
		}

    }
}
