﻿using System;
using Newtonsoft.Json;

namespace DriverLocator.Models
{
	public class SelectedUserCoordinateResponse : ResponseBase
	{
		[JsonProperty("userName")]
		public string UserName { get; set; }

		[JsonProperty("email")]
		public string EMail { get; set; }

		[JsonProperty("name")]
		public string Name { get; set; }

		[JsonProperty("longitude")]
		public string Longitude { get; set; }

		[JsonProperty("latitude")]
		public string Latitude { get; set; }
	}
}

