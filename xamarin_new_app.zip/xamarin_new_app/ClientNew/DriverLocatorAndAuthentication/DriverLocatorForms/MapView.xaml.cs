﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace DriverLocatorForms
{
	public partial class MapView : ContentPage
	{
		DriverLocator.DriverLocatorService driverLocatorService = new DriverLocator.DriverLocatorService (Session.AuthenticationService);

		public MapView ()
		{
			InitializeComponent ();
			LoadUserData ();
		}

		private void LoadUserData()
		{
			var userCorrdinates=driverLocatorService.ViewUserCoordinates ();
			foreach (var userCorrdinate in userCorrdinates.UserCoordinates) 
			{
				messageLabel.Text += userCorrdinate.UserName + "|" + userCorrdinate.EMail + "|" + userCorrdinate.Name + "|" + userCorrdinate.Longitude + "|" + userCorrdinate.Latitude + Environment.NewLine;
			}
		}

		async void OnLogoutButtonClicked (object sender, EventArgs e)
		{
			App.IsUserLoggedIn = false;
			Navigation.InsertPageBefore (new Login (), this);
			await Navigation.PopAsync ();
		}


		async void OnChangeCoordinateButtonClicked(object sender, EventArgs e)
		{
			Navigation.InsertPageBefore(new CreateUser(), this);
			await Navigation.PopAsync();
		}
	}
}

