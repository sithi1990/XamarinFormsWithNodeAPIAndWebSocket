﻿using System;
using System.Collections.Generic;
using Authentication.Models;
using Xamarin.Forms;

namespace DriverLocatorForms
{
	public partial class SignUp : ContentPage
	{
		public SignUp ()
		{
			InitializeComponent ();
		}

		async void OnSignUpButtonClicked (object sender, EventArgs e)
		{
			var user = new User() {
				UserName = UserName.Text,
				EMail=EMail.Text,
				Password = Password.Text,
			};


			var signUpSucceeded = AreDetailsValid (user); 

			if (signUpSucceeded) 
			{

				var result = Session.AuthenticationService.CreateUser(user);
				await Navigation.PushAsync(new Login());
			} 
		    else 
			{
				messageLabel1.Text = "Sign up failed";
			}
		}

		bool AreDetailsValid (User user)
		{
			return (!string.IsNullOrWhiteSpace (user.UserName) &&
				!string.IsNullOrWhiteSpace (user.Password) &&
				!string.IsNullOrWhiteSpace (user.UserName) &&
				!string.IsNullOrWhiteSpace (user.EMail));           
		}
	}
}

