﻿using System;
using System.Collections.Generic;
using DriverLocator.Models;
using DriverLocator;
using Authentication.Common;
using Authentication.Models;
using Authentication;
using Xamarin.Forms;

namespace DriverLocatorForms
{
	public partial class Login : ContentPage
	{
		public Login ()
		{
			InitializeComponent ();
			Session.AuthenticationService = new AuthenticationService();
		}

		async void OnLoginButtonClicked (object sender, EventArgs e)
		{
			var user = new User {
				UserName = usernameEntry.Text,
				Password = passwordEntry.Text
			};


			var isValid = AreCredentialsCorrect (user);
			if (isValid) {

				DriverLocator.DriverLocatorService driverLocatorService= new DriverLocator.DriverLocatorService(Session.AuthenticationService);
				var userCorrdinateResult = driverLocatorService.GetSelectedUserCoordinate ();

				if (userCorrdinateResult.IsSuccess) {
					await Navigation.PushAsync (new MapView ());
				} 
				else 
				{
					await Navigation.PushAsync (new CreateUser());
				}

			} 
			else 
			{
				messageLabel.Text = "Login failed";
				passwordEntry.Text = string.Empty;
			}
		}

		async void OnSignUpButtonClicked(object sender, EventArgs e)
		{
			try
			{
				Navigation.InsertPageBefore (new SignUp (), this);
				await Navigation.PopAsync ();
			}
			catch(Exception ex) 
			{
			}

		}

		bool AreCredentialsCorrect (User user)
		{
			if (Session.AuthenticationService.Authenticate(user.UserName, user.Password))
			{
				return true;
			}
			return false;
		}
	}
}

