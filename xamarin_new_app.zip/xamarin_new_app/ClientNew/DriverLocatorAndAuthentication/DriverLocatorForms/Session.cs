﻿using Authentication.Common;

namespace DriverLocatorForms
{
	public static class Session
	{
        public static IAuthenticationService AuthenticationService { get; set; }
	}
}
