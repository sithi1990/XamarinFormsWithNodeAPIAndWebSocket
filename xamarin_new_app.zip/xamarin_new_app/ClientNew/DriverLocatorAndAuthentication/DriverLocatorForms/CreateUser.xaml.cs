﻿using System;
using System.Collections.Generic;
using DriverLocator.Models;
using Xamarin.Forms;

namespace DriverLocatorForms
{
	public partial class CreateUser : ContentPage
	{
		SelectedUserCoordinateResponse userCoordinate;
		DriverLocator.DriverLocatorService driverLocatorService = new DriverLocator.DriverLocatorService (Session.AuthenticationService);
		public CreateUser ()
		{
			InitializeComponent ();
			FillUserData ();
		}

		public CreateUser (SelectedUserCoordinateResponse userCoordinate)
		{
			InitializeComponent ();
			this.userCoordinate = userCoordinate;
			FillUserData ();
		}

		private void FillUserData()
		{
			if (userCoordinate != null) 
			{

				UserName.Text = userCoordinate.UserName;
				EMail.Text = userCoordinate.EMail;
				Name.Text = userCoordinate.Name;
				Longitude.Text = userCoordinate.Longitude;
				Latitude.Text = userCoordinate.Latitude;
			} 
			else 
			{
				var userInfo = Session.AuthenticationService.GetUserInfo (Session.AuthenticationService.AuthenticationToken);
				UserName.Text = userInfo.UserName;
				EMail.Text = userInfo.EMail;
			}

		}

		async void OnSaveButtonClicked(object sender, EventArgs e)
		{
			try
			{
				UserCoordinate userCoordinate = new UserCoordinate();
				userCoordinate.UserName =  UserName.Text;
				userCoordinate.EMail =  EMail.Text;
				userCoordinate.Name =  Name.Text;
				userCoordinate.Longitude = Longitude.Text;
				userCoordinate.Latitude = Latitude.Text;
				var result = driverLocatorService.SaveUserData(userCoordinate);
				Navigation.InsertPageBefore(new MapView(), this);
				await Navigation.PopAsync();
			}
			catch(Exception ex)
			{
				throw ex;
			}

		}

	}
}

