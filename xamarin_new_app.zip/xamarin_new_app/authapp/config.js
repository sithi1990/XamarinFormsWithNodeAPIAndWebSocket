module.exports = {

    'secret': 'vappsecret',
    'database': 'mongodb://localhost:27017/authapp'

};